package coo2018.ui.controller.chaine;

public interface ITransformation {

	public void transforme();
}
