package coo2018.values;

import javafx.geometry.Insets;

public class Dimens {

	public static Insets padding_vbox_champs_element = new Insets(0.0, 0.0, 0.0, 20.0);
	public static double spacing_vbox_champs_element = 10.0;
	
}
